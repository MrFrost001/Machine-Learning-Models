import streamlit as st
import pickle
import warnings
warnings.filterwarnings('ignore')

# python -m streamlit run main.py

st.title("Student Marks Predictor")
sh=st.number_input("Enter study Hours")
btn=st.button("Predict")
if btn:
    if sh<=12:
        model=pickle.load(open("smp.pkl","rb"))
        res=model.predict([[sh]])[0][0].round(2)
        st.success(f"Prediction Marks :{res}")
    else:
        st.warning("Invalid Input")


