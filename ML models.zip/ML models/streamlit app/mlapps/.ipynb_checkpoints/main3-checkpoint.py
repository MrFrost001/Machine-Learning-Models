import streamlit as st
import pickle
import warnings
warnings.filterwarnings("ignore")

st.title("Iris Flower Prediction")
a=st.number_input("enter the lenght of sepal (range 4.3-7.9)")
b=st.number_input("enter the width of sepal (range 2.0-4.4)")
c=st.number_input("enter the length of petal (range 1.0-6.9)")
d=st.number_input("enter the width of petal (range 0.1-2.5)")
btn=st.button("Predict")

if btn:
    if a>4 and b>2 and c>1 and d>0:
        model=pickle.load(open("fp.pkl","rb"))
        Y_pred=model.predict([[a,b,c,d]])
        st.success(f"Iris flower type is:-{Y_pred[0]}")
    else:
        st.warning("invalid input")    