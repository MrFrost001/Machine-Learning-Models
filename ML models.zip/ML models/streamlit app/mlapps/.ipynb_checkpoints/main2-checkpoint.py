import streamlit as st
import pickle
import warnings
warnings.filterwarnings("ignore")

st.title("Weather Prediction")
a=st.number_input("enter the precipitation (range 0-55)")
b=st.number_input("enter the max temp (range -1.5-35 )")
c=st.number_input("enter the min temp (range -7.1-18)")
d=st.number_input("enter the wind (range 0.4-9)")
btn=st.button("Predict")

if btn:
    if a<55 and b<35 and c<18 and d<9:
        model=pickle.load(open("wp.pkl","rb"))
        Y_pred=model.predict([[a,b,c,d]])
        st.success(f"Weather will be :- {Y_pred[0]}")
    else:
        st.warning("invalid input")
